﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_28
{
    class Orders:Products
    {
        static int orderid = 0;
        public int qty;
        public float totprice;

        public Orders()
        {
            Console.WriteLine("Enter the quantity = ");
            qty = int.Parse(Console.ReadLine());
            orderid++;
            totprice = qty * price;
        }
        public void display()
        {
            base.display();

            Console.WriteLine("ORDERID            " + orderid);
            Console.WriteLine("QUANTITY         " + qty);
            Console.WriteLine("TOTAL PRICE        " + totprice);
        }
        public string Mydata()
        {
            string mystring = "";
            mystring += "ORDER ID :" + orderid;

            mystring += "| CATEGORY ID :" + catid;
            mystring += "| CATEGORY NAME :" + catname;
            mystring += "| CATEGORY TYPE :" + cattype;
            mystring += "| PRODUCT ID :" + pid;
            mystring += "| PRODUCT NAME :" + pname;
            mystring += "| PRODUCT PRICE :" + price;
            mystring += "| QUANTITY :" + qty;
            mystring += "| TOTAL PRICE :" + totprice;
            mystring += "\n";

            return mystring;


        }

    }
}
