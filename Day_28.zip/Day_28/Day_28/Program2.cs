﻿using System;
using System.IO;

namespace Day_28
{
    class Program2
    {
        static void Main(string[] args)
        {
            float bill = 0;
            
            StreamWriter sw = new StreamWriter("E:\\Orders1.txt",true);
            
            int ch;
            do
            {
                Orders ob = new Orders();
                ob.display();
                sw.WriteLine(ob.Mydata());

                bill += ob.totprice;
                Console.WriteLine(ob.Mydata());
                Console.WriteLine("________________________________________");
                Console.WriteLine("If you want to continue shopping PRESS 1");
                ch = int.Parse(Console.ReadLine());
            } while(ch==1);
            Console.WriteLine("BILL = " +bill);

            sw.Close();
            
        }
    }
}
