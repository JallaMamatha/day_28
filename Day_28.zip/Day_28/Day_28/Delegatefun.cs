﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
delegate int Myfun(int n);
delegate int Myfun1(int n, int m);
delegate int Square(int num);
delegate int Inc(int num);

namespace Day_28
{
    class Delegatefun
    {
        static int x;
        Delegatefun()
        {
            x = 10;
        }
        public int incrementme(int a)
        {
            a++;
            x = a;
            return a;
        }

        public int incrementmeten(int a)
        {
            a += 10;
            x = a;
            return a;
        }
        public static int add(int a,int b)
        {
            return a + b;
        }
        static void Main(string[] args)
        {
            Myfun ob = new Myfun(new Delegatefun().incrementme);
            Console.WriteLine("Increment me = " +ob(8));

            Delegatefun obnew = new Delegatefun();
            Myfun ob1 = new Myfun(new Delegatefun().incrementmeten);
            Console.WriteLine("Increment me  10 = " + ob1(5));


            Myfun1 ob2 = new Myfun1(add);
            Console.WriteLine("Increment me = " + ob2(3,6));



            Square mysquare = x => x * x;

            int sq1 = mysquare(9);
            Console.WriteLine("MYSQUARE = " +sq1);

            Inc increby20 = x => x + 20;
            int in1 = increby20(11);
            Console.WriteLine("Increment by 20 = "+in1);
        }
    }
}
