﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Day_28
{
    class Categories
    {
        public int catid;
        public string catname, cattype;

        public Categories()
        {

            Console.WriteLine("Enter the CATEGORY ID");

            catid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the CATEGORY NAME");
            catname = Console.ReadLine();
            Console.WriteLine("Enter the CATEGORY TYPE");
            cattype = Console.ReadLine();

        }

        public void display()

        {
         

            Console.WriteLine("CATID            " + catid);
            Console.WriteLine("CATNAME          " + catname);
            Console.WriteLine("CATTYPE         " + cattype);
        }
    }
}
