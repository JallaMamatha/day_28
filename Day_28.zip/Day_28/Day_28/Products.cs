﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_28
{
    class Products:Categories
    {
        public int pid;
        public string pname;
        public float price;
        public Products()
        {
            Console.WriteLine("Enter the PID");

            pid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the PNAME");
            pname = Console.ReadLine();
            Console.WriteLine("Enter the PRICE");
            price = float.Parse(Console.ReadLine());


        }

        public void display()
        {
            base.display();
            Console.WriteLine("PID            "+pid);
            Console.WriteLine("PNAME          "+pname);
            Console.WriteLine("PRICE          "+price);
        }
    }
}
