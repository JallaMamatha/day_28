﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_28
{
    class StringEx
    {

        static void fun3()
        {
            string s1 = "Hi this is a sample line";
            string s2 = "sample";
            string s3 = "lines";
            Console.WriteLine(s1.Contains(s2));
            Console.WriteLine(s1.EndsWith(s3));
            Console.WriteLine(s1.StartsWith("Hi"));

           string s4 = s3.Insert(2, "_______________________");
            Console.WriteLine(s4);
            string s6 = string.Concat(s2, s3);
            Console.WriteLine(s2 + " " + s3 + s6);
            int ind = s1.IndexOf('i');
            Console.WriteLine(ind);
            Console.WriteLine(s1.Substring(2,10));

            string[] d = { "hey", "this", "is", "array" };
            string s8 = string.Join("****",d);
            Console.WriteLine(s8);

            s2 = s2.ToUpper();
            Console.WriteLine(s2);

            Console.WriteLine(s2 + " =" + s2.ToLower());

            string d1 = s2.PadLeft(20);
            Console.WriteLine(d1);


            string d2 = s2.PadLeft(10);
            Console.WriteLine(d2);
            Console.WriteLine("*********************");


            d2 = "AtuvavbA";
            string d3 = d2.Replace('A', 'Z');
            Console.WriteLine(d3);

            d3 = "mamatha";
            string d4 = d3.Remove(1,4);
            Console.WriteLine(d4);

            char[] d5 = d2.ToCharArray();
            foreach(char c in d5)
                Console.WriteLine(c);


            string n = "heyHi";
            StringBuilder x1 = new StringBuilder();
            x1.Append("heyHi");
            StringBuilder x2 = new StringBuilder();
            x2.Append("heyHi");
            Console.WriteLine(string.Compare(n,x1.ToString()));




        }
        static void fun2()
        {
            string s1 = "APPLE", s2 = "MANGO", s3 = "APPLE";
            Console.WriteLine(s1==s3);
            Console.WriteLine(string.Compare(s1,s2));
            Console.WriteLine(string.Compare(s1, s3));
            Console.WriteLine(string.Compare(s3, s2));
            Console.WriteLine(object.ReferenceEquals(s1,s2));


            string a = "Mystring";
            string b = a;
            Console.WriteLine(string.Compare(a,b));
            Console.WriteLine(object.ReferenceEquals(a,b));
            Console.WriteLine();
            string s4 = (String)s1.Clone();
            Console.WriteLine(string.Compare(s1,s4));
            Console.WriteLine(object.ReferenceEquals(s1,s4));

            Console.WriteLine();

            char[] a1 = { 'A', 'P', 'P' };
            String ob = new String(a1);
            string ob2 = "APP";
            Console.WriteLine(string.Compare(ob,ob2));
            Console.WriteLine(ob==ob2);







        }
        static void Main(string[] args)
        {

            fun3();
        }






            static void fun1()
            {



                string s = "ORDER ID :1| CATEGORY ID :34| CATEGORY NAME :dfghj| CATEGORY TYPE :dfg|" +
                    " PRODUCT ID :345| PRODUCT NAME :fghj| PRODUCT PRICE :45| QUANTITY :2| TOTAL PRICE :90";


                string[] s2 = s.Split('|');  //pipeline

                foreach (string x in s2)
                    Console.WriteLine(x);
            }
        }
    }

